# EAS Finance Workspace — Development Scope Lock

This is the regression baseline for the Development module.

## Locked product principle

Quick and Detailed are different input depths over the same underlying development-finance logic. A later UI refactor must not silently drop finance timing, liquidity, exit, actual/forecast or funding mechanics.

## Quick Development Test

- One project works on its own; up to four can be compared.
- Ground-up, conversion, heavy refurbishment, light refurbishment and part-complete.
- Project-specific acquisition/current site value, debt where owned, build cost, fees, contingency, GDV, works/exit periods, units and cash.
- Common editable finance assumptions.
- Defaults: 12.0% p.a. interest, 2.0% arrangement fee, 0% exit fee, rolled interest, 100% works funding, 100% professional-fee funding, 65% acquisition funding, one-month certification lag.
- Monthly generated profile; time changes interest, peak debt and liquidity.
- Show pre-finance and after-finance economics, finance cost, project funding need, day-one advance, peak/gross facility need, peak debt/GDV, peak debt/cost, developer equity, additional liquidity/equity, exit shortfall and equity return/IRR.
- Stress: build cost, GDV, build period, sales period and combined downside.
- Promote any project to Detailed without re-keying.

## Detailed Development Model

- Purchased or already-owned land/site.
- Historic land cost, current value/economic contribution and cash requirement separate.
- Monthly cashflow; imported/generated monthly data authoritative for finance timing.
- Actual periods immutable; scenarios affect forecast only.
- Senior and optional mezzanine.
- Acquisition/works/professional funding eligibility percentages.
- Facility limit/headroom.
- Certification/reimbursement lag.
- Rolled or serviced interest.
- Arrangement/exit/refinance fees.
- Timed jump costs and contingency consumption.
- Phased sales, sales/disposal costs, release percentage/minimum release.
- Imported sales rows can drive exit timing; actual sales remain locked in scenarios.
- Part-sell/part-retain and retained-unit refinance.
- Development exit-finance comparison and fee-inclusive break-even horizon.
- Developer equity IRR.
- Monthly ledger with senior/mezz draws, repayments and balances.
- Excel/CSV import mapping: Period, Status, Category, Subcategory, Description, Forecast, Actual, Source.
- Excel export: inputs, monthly ledger, scenarios, imported cost plan.
- JSON model manifest with schema/version.

## Deliberate boundaries

- No lender fundable/not-fundable verdict.
- No claim of live lender criteria/pricing unless a live governed market layer is connected.
- No regulated residential mortgage route.
- No tax, formal valuation or planning-prediction engine.
- Generic monthly interest convention; lender-specific daily/day-count belongs in a lender overlay.
