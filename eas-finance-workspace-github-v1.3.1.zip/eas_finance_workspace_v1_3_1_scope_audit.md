# EAS Finance Workspace v1.3.1 — Thorough Scope Restoration Audit

## Why this audit was done

The one-to-four-project Development interface had become easier to use, but several original development-finance mechanics had been lost or were no longer connected to the borrower-facing calculations. The principal example was works/exit timing being collected while finance cost was not being calculated.

The audit therefore compared the current browser workspace against the earlier Development core specification and prototype capabilities rather than treating the latest screen as the specification.

## Restored / reconnected in Development v3.1

### One finance engine behind Quick and Detailed

Quick and Detailed now use the same monthly development cash-flow mechanics at different input depths.

### Quick Development Test

- One to four projects.
- Ground-up, conversion, heavy refurbishment, light refurbishment and part-complete types.
- Type-sensitive contingency defaults where the user has not overridden them.
- Common finance assumptions across compared projects.
- 12.0% p.a. default interest.
- 2.0% arrangement fee.
- 0% exit fee.
- Rolled or serviced interest.
- 100% works funding test.
- 100% professional-fee funding test.
- 65% acquisition funding starting assumption.
- Certification/reimbursement lag.
- S-curve cost timing, with light-refurbishment straight/even profile.
- Finance cost changes when build or sales period changes.
- Project funding need before finance.
- Day-one advance/debt created.
- Indicative gross facility requirement / peak debt.
- Profit before and after estimated finance.
- Peak debt/GDV and peak debt/project cost.
- Developer equity and additional liquidity requirement.
- Exit shortfall.
- Equity IRR.
- Live project-card refresh when inputs change.
- Multi-project scenario comparison.
- Promotion into Detailed without re-keying principal figures or finance assumptions.

### Detailed Development Model

- Bought versus already-owned site.
- Historic land cost versus current value.
- Current value/economic site contribution is not treated as cash.
- Acquisition costs.
- Monthly generated or imported cost schedule.
- Native Excel/CSV import path.
- Column mapping and category synonyms.
- Imported monthly data becomes authoritative for finance timing when selected.
- Actual/forecast period status.
- Actual costs remain fixed in scenario reforecasting.
- Imported actual sales remain fixed; forecast sale rows can move/stress.
- Senior facility and optional mezzanine.
- Separate acquisition, works and professional funding percentages.
- Facility cap/headroom.
- Certification lag.
- Rolled/serviced interest.
- Arrangement, exit and refinance fees.
- Contingency and timed jump events.
- Sale releases by percentage or minimum amount.
- Sales/disposal costs.
- Part-sell/part-retain.
- Retained-unit refinance.
- Exit-finance comparison.
- Fee-inclusive break-even horizon for switching to exit finance.
- Developer equity IRR.
- Monthly ledger with senior/mezz draws, separate repayments and closing balances.
- Scenarios: build +10%, GDV -10%, build delay, sales delay and combined downside.
- Excel export and JSON model manifest.

## Important regressions found by the audit

1. Quick Development had stopped charging finance at all.
2. Works and sales periods therefore did not affect money results.
3. Project-card summaries could become stale while underlying inputs changed.
4. Quick and Detailed had diverged into different finance logic.
5. Acquisition/day-one funding was effectively treated as 100% in Quick.
6. Quick conversion/refurbishment had collapsed several development types into one generic option.
7. Imported spreadsheet sales rows were being ignored by the finance engine.
8. Senior/mezz repayments were aggregated in the browser ledger rather than visibly traceable.
9. Gross/peak facility requirement and day-one advance were not explicit borrower outputs.
10. Part-complete projects could be treated too much like fresh projects without actual-cost evidence.
11. The original scope was living in conversation history rather than a regression baseline.

All of the above have now either been corrected in v1.3.1 or, in the final item, addressed by a permanent Development Scope Lock.

## Current validation

The v1.3.1 build has been checked with separate suites rather than one inflated headline test count:

- Development monthly finance engine: 31/31
- Quick/Detailed browser workflow: 19/19
- Non-development route regression/mobile smoke: 17/17
- Actual/forecast locking: 7/7
- Development-type/default governance: 4/4
- Sidebar/final-result behaviour: 7/7
- Quick subtype switching/default preservation: 6/6
- Imported sales/actual locking: 7/7
- Finance-scope/day-one/acquisition-funding transfer: 13/13
- Part-complete validation: 2/2 (previous run; retained logic)
- JavaScript syntax: PASS

These suites overlap in places and should not be added together as a claim of unique independent tests.

## What is still deliberately not complete

### Development

- Real-world calibration against completed EAS/developer cases and lender models.
- Empirical calibration of generated monthly cost curves by project type.
- Per-unit unequal sale values/rents in the quick interface.
- Full lender-specific cost-category eligibility matrices beyond the current acquisition/works/professional structure.
- Lender-specific daily interest/day-count conventions.
- Live lender criteria and pricing layer.
- Full long-term retained-investment model after development refinance.
- Production vendoring of the Excel library and live GitHub end-to-end XLSX upload/download testing.
- Formal import of the JSON model manifest with schema validation.

### Other finance routes

The broad-finance routes remain useful quick views, but they are not all at the same depth as Development:

- Commercial owner-occupied purchase: useful quick affordability/leverage view.
- Investment property purchase: useful quick stressed-rent/leverage view.
- Bridging: still simpler than the validated bridging engine; interest-treatment differences are not fully surfaced in the browser result.
- Refinance / retain: currently too dependent on short-term bridging mechanics; the long-term retained-property path needs its own UI.
- Business acquisition: useful quick sources/uses and cover view; detailed senior/vendor/deferred repayment profiles are not yet surfaced.
- Working capital: currently centred on a term-loan comparison; revolver/overdraft-style alternatives are not yet surfaced.
- Asset finance: payment view is useful, but the selected HP/lease structure does not yet change all economics/ownership outputs.
- Invoice finance: borrowing-base view is useful; the wider ABL pools (stock, plant, property) are not yet surfaced in the UI.

These are now recorded as explicit product gaps rather than being treated as completed features.

## Product judgement

Development v3.1 is substantially closer to the original intended product: fast enough for opportunity screening, but with real finance timing underneath it. The remaining Development gaps are now identifiable extensions rather than lost core mechanics.

The broad modules should be frozen as quick views while Development is calibrated and completed, unless a user-visible route currently overstates what it does.
